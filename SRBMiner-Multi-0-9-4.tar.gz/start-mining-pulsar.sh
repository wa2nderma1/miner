#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

./SRBMiner-MULTI --disable-gpu --algorithm curvehash --pool stratum-eu.rplant.xyz:7030 --wallet your-wallet-here

