#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

./SRBMiner-MULTI --disable-gpu --algorithm randomyada --pool yadacoin.io:3333 --wallet 18uVpjsX3RMGtRvozcMwwZz2Pd5qLyqFnH
